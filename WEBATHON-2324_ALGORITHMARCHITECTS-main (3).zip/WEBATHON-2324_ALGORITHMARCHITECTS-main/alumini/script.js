document.getElementById('studentCard').addEventListener('click', function() {
  window.location.href = 'student_login.html'; // Redirect to student login page
});

document.getElementById('alumniCard').addEventListener('click', function() {
  window.location.href = 'alumni_login.html'; // Redirect to alumni login page
});